
import HW2

if __name__ == '__main__':

    HW2.Run()




